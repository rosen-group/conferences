import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

pytest_plugins = ["docker_compose"]


@pytest.fixture(scope="function")
def wait_for_api(function_scoped_container_getter):
    """Wait for the api to become responsive"""
    request_session = requests.Session()
    retries = Retry(total=5, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
    request_session.mount("http://", HTTPAdapter(max_retries=retries))

    api_url = "http://localhost:80/healthcheck"
    assert request_session.get(api_url)
    return request_session, api_url


def test_healthcheck(wait_for_api):
    """Test the response of the healthcheck."""
    request_session, api_url = wait_for_api
    item = request_session.get("http://localhost:80/healthcheck").json()
    assert item["ready"] == True


def test_vote(wait_for_api):
    """Test whether voting works correctly."""
    request_session, api_url = wait_for_api
    item = request_session.get("http://localhost:80/vote").json()
    assert item["votes"] == 1
    item = request_session.get("http://localhost:80/vote").json()
    assert item["votes"] == 2
