import os
import time

import docker
import pytest

import requests

WAIT_TIME_FOR_CONTAINERS = 10


def teardown_container(container):
    container.kill()
    container.stop()
    container.remove()


@pytest.fixture(scope="module")
def setup_containers():
    client = docker.from_env()
    client.images.build(path=".", tag="my_api")
    print(
        "Starting api container and sleeping {} seconds".format(
            WAIT_TIME_FOR_CONTAINERS
        )
    )
    api_container = client.containers.run(
        "my_api", detach=True, name="my_api_test", ports={"80/tcp": 80}
    )
    time.sleep(WAIT_TIME_FOR_CONTAINERS)
    yield api_container
    teardown_container(api_container)


def test_list_assets(setup_containers):
    url = r"http://localhost:80/items/11"
    r = requests.get(url)
    assert r.status_code == 200
    assert r.json() == {"item_id": 11}
