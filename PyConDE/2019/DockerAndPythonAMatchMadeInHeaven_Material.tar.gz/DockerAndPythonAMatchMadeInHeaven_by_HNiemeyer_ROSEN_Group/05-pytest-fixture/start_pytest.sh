#!/bin/bash

pytest test.py --cap=no
