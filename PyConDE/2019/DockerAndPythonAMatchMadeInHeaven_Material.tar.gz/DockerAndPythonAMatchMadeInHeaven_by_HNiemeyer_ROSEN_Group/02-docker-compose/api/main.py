from fastapi import FastAPI
import redis

cache = redis.Redis(host='redis', port=6379)
app = FastAPI()


@app.get("/vote")
async def read_item():
    number_of_votes = cache.incr('votes')
    return {"votes": number_of_votes}
